import CalledDecisoinCustomProvider from "./CalledDecisionCustomProvider";
export default {
  __init__: [ 'calledDecisoinCustomProvider' ],
  calledDecisoinCustomProvider: [ 'type', CalledDecisoinCustomProvider ]
};